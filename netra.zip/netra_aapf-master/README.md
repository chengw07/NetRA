# NetRA version 1.0

# Install 
pip install all packages in `requirements.txt`

## Run

running with user defined dataset

supervised training

```
> from netra.netra import netra
> netra('./data/cora/cora.cites', './data/cora/cora.content', './tmp/')
> netra('./data/cora/cora.cites', './data/cora/cora.content', './tmp/', supervise=True, train_percent=0.7)
```

unsupervised training
```
> from netra.netra import nerta
> netra('./data/cora/cora.cites', './data/cora/cora.content', './tmp/', supervise=False, emsize=128)
```






