from setuptools import setup, find_packages

"""
setup file for NetRA package.

author: shuchu@nec-labs.com
"""


with open('README.md', 'r') as f:
    long_discription = f.read()


setup(
    name="netra",
    version="1.0.0",
    description="NetRA graph embedding.",
    long_description=long_discription,
    long_description_content_type='text/plain',
    packages=find_packages(),
    install_requires=['numpy',
                      'scipy',
                      'scikit-learn',
                      'torch>=0.4.0',
                      'networkx',
                      'matplotlib',
                      'pandas'],
)

