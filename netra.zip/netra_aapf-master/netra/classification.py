from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.preprocessing import normalize

import numpy as np
from netra.configs import logger


def score_classification(features, z, p_labeled=0.9, n_repeat=2, norm=False):
    """
    Train a classifier using the node embeddings as features and reports the performance.
    :param features: array-like, shape [N, L]
    :param z: array-like, shape [N], labels
    :param p_labeled: float, Percentage of nodes to use for training the classifier
    :param n_repeat: Number of times to repeat the experiment
    :param norm: normalization
    :return: mean and var of F_1 Score (micro and macro)
    """

    lrcv = LogisticRegression()
    features = features.detach().cpu().numpy()
    if norm:
        features = normalize(features)

    micro_trace, macro_trace = [], []
    for seed in range(n_repeat):
        sss = StratifiedShuffleSplit(n_splits=1, test_size=1 - p_labeled, random_state=seed)
        split_train, split_test = next(sss.split(features, z))

        lrcv.fit(features[split_train], z[split_train])
        predicted = lrcv.predict(features[split_test])

        f1_micro = f1_score(z[split_test], predicted, average='micro')
        f1_macro = f1_score(z[split_test], predicted, average='macro')

        micro_trace.append(f1_micro)
        macro_trace.append(f1_macro)

    logger.info("classification with %.2f%% percent labeled data..." % (p_labeled * 100))
    logger.info("validation set F1: {:.4f}".format(np.array(micro_trace).mean()))

    return np.array(micro_trace).mean(), np.array(micro_trace).var(), np.array(macro_trace).mean(), np.array(macro_trace).var()

