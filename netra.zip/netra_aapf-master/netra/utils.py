import torch
import numpy as np
import random
import networkx as nx
from math import floor
from sklearn.manifold import SpectralEmbedding
from collections import defaultdict

from netra.configs import logger

def to_gpu(gpu, var):
    if gpu:
        return var.cuda()
    return var


def batchify(data, bsz, shuffle=False, gpu=False):
    """
    generate a batch of data for training
    :param data: input data
    :param bsz: batch size
    :param shuffle: shuffle the data
    :param gpu: if use gpu
    :return: a batch of data
    """
    if shuffle:
        random.shuffle(data)

    nbatch = len(data) // bsz
    batches = []

    for i in range(nbatch):
        # Pad batches to maximum sequence length in batch
        batch = data[i*bsz:(i+1)*bsz]
        # subtract 1 from lengths b/c includes BOTH starts & end symbols
        words = batch
        lengths = [len(x) for x in words]

        source = [x for x in words]
        target = [x for x in words]

        source = torch.LongTensor(np.array(source))
        target = torch.LongTensor(np.array(target)).view(-1)

        if gpu:
            source = source.cuda()
            target = target.cuda()

        batches.append((source, target, lengths))
    # logger.info('total batches: {}'.format(len(batches)))
    return batches


def __random_walk(graph, path_length, alpha=0, rand=random.Random(), start=None):
    """
    returns a truncated random walk.
    :param graph: input graph
    :param path_length: length of the random walk.
    :param alpha: probability of restarts.
    :param rand: random seeds
    :param start: the start node of the random walk.
    :return: walks
    """
    if start:
        path = [start]
    else:
        # Sampling is uniform w.r.t V, and not w.r.t E
        path = [rand.choice(list(graph.nodes))]

    while len(path) < path_length:
        cur = path[-1]
        if len(list(graph.neighbors(cur))) > 0:
            if rand.random() >= alpha:
                path.append(rand.choice(list(graph.neighbors(cur))))
            else:
                path.append(path[0])
        else:
            break
    return [node for node in path]


def generate_walks(graph, walk_per_node, walk_length, alpha=0, rand=random.Random(0)):
    """
    return generated walk set
    :param graph: input graph
    :param walk_per_node: walk number per node
    :param walk_length: length of the random walk
    :param alpha: probability of restarts
    :param rand: random seeds
    :return: set of walks
    """
    walks = []
    nodes = list(graph.nodes())
    for cnt in range(walk_per_node):
        rand.shuffle(nodes)
        for node in nodes:
            walks.append(__random_walk(graph, walk_length, rand=rand, alpha=alpha, start=node))
    return walks


def export_embeddings(embeddings, indices, args):
    results = []
    dic = list(args.raw_data.dictionary.items())
    for idx in indices:
        name = [dic[idx][0]]
        name.extend(embeddings[idx])
        results.append(name)
    np.savetxt(args.out_folder + "embeddings.txt", results, delimiter=",", fmt='%s')
    logger.info("embedding results saved to: %s" % (args.out_folder + "embeddings.txt"))


class Dataset(object):
    """
    Class dataset processing
    """
    def __init__(self, args):
        self.graph_file = args.edge_path
        self.attribute_file = args.content_path
        # self._get_path()

        self.dictionary = {}
        self.samples = {}
        self.labels = {}
        self.label_dict = {}
        self.attribute_dim = 0
        self._load_attribute_data()

        self._get_adj_list()

        self.edge_list = []
        self._load()

        self.avg_degree = 0
        self.graph = nx.Graph()
        self._get_graph()

        self.num_class = len(set(self.labels.values()))

    # def _get_path(self):
    #     if self.name == 'citeseer' or self.name == 'cora':
    #         self.graph_file = '../data/{0}/{0}.cites'.format(self.name)
    #         self.attribute_file = '../data/{0}/{0}.content'.format(self.name)
    #         logger.debug('graph file: %s' % self.graph_file)
    #         logger.debug('attribute file: %s' % self.attribute_file)
    #     else:
    #         logger.error('cannot find dataset %s' % self.name)

    def _load_attribute_data(self):
        with open(self.attribute_file) as samples:
            for sample in samples:
                line = sample.strip().split('\t')
                if not self.attribute_dim:
                    self.attribute_dim = len(line) - 2
                assert self.attribute_dim == len(line) - 2
                if line[0] not in self.dictionary:
                    self.dictionary[line[0]] = len(self.dictionary)
                vertex_id = self.dictionary[line[0]]
                # TODO there might be cases with float attributes
                self.samples[vertex_id] = [int(att) for att in line[1:-1]]
                self.labels[vertex_id] = line[-1]

                if line[-1] not in self.label_dict:
                    self.label_dict[line[-1]] = len(self.label_dict)

        assert len(self.samples) == len(self.dictionary)

    def _get_adj_list(self):
        num_nodes = len(self.samples)
        num_feats = self.attribute_dim
        feat_data = np.zeros((num_nodes, num_feats))
        labels = np.empty((num_nodes, 1), dtype=np.int64)
        node_map = {}
        label_map = {}
        with open(self.attribute_file) as fp:
            for i, line in enumerate(fp):
                info = line.strip().split()

                feat_data[i, :] = [float(k) for k in info[1:-1]]
                node_map[info[0]] = i
                if not info[-1] in label_map:
                    label_map[info[-1]] = len(label_map)
                labels[i] = label_map[info[-1]]

        adj_lists = defaultdict(set)
        with open(self.graph_file) as fp:
            for i, line in enumerate(fp):
                info = line.strip().split()
                if info[0] not in node_map or info[1] not in node_map:
                    continue
                paper1 = node_map[info[0]]
                paper2 = node_map[info[1]]
                adj_lists[paper1].add(paper2)
                adj_lists[paper2].add(paper1)
        self.feature_mat, self.label_vec, self.adj_list = feat_data, labels, adj_lists

    def _load(self):
        with open(self.graph_file) as edgelists:
            for edge in edgelists:
                u, v = edge.strip().split('\t')
                if u not in self.dictionary or v not in self.dictionary:
                    # logger.warning('skip edge with unknow vertex')
                    continue
                if (self.dictionary[u], self.dictionary[v]) in self.edge_list or \
                        (self.dictionary[v], self.dictionary[u]) in self.edge_list:
                    # logger.warning('duplicate edges')
                    continue
                self.edge_list.append((self.dictionary[u], self.dictionary[v]))

    def _get_graph(self):
        """
        current implementation only consider undirected graph
        :return: networx Graph()
        """
        self.graph.add_edges_from(self.edge_list)
        self.avg_degree = sum([degree for (_, degree) in self.graph.degree]) / len(self.graph)
        self.laplacian = nx.laplacian_matrix(self.graph)

    def random_walk(self, path_length, alpha=0, rand=random.Random(), start=None):
        if start:
            path = [start]
        else:
            # Sampling is uniform w.r.t V, and not w.r.t E
            path = [rand.choice(list(self.graph.nodes))]

        while len(path) < path_length:
            cur = path[-1]
            if len(list(self.graph.neighbors(cur))) > 0:
                if rand.random() >= alpha:
                    path.append(rand.choice(list(self.graph.neighbors(cur))))
                else:
                    path.append(path[0])
            else:
                break
        return [str(node) for node in path]

    def get_train_samples(self, train_percent):
        train_num = floor(len(self.dictionary) * train_percent)
        keys = random.sample(list(self.dictionary.values()), train_num)
        train_x = [self.samples[k] for k in keys]
        train_y = [self.labels[k] for k in keys]
        test_x = [self.samples[k] for k in self.samples if k not in keys]
        test_y = [self.labels[k] for k in self.labels if k not in keys]
        logger.debug('training samples vs. testing samples: %d (%.2f%%) vs. %d'
                     % (train_num, train_num / (train_num + len(test_y)) * 100, len(test_x)))
        return np.array(train_x), np.array(train_y), np.array(test_x), np.array(test_y)

    def print_info(self):
        logger.info('')
        logger.info('dataset description')
        logger.info('#vertices: %d, #edges: %d, avg. degree: %.2f, #attributes: %d, #classes: %d'
                    % (len(self.dictionary), len(self.edge_list), self.avg_degree, self.attribute_dim, self.num_class))

    def visualization(self):
        catgories = ['AI', 'DB', 'HCI', 'Agents', 'IR', 'ML']
        ids = [v for v in self.labels if self.labels[v] in catgories]
        graph = self.graph.subgraph(ids)
        giant = max(nx.connected_component_subgraphs(graph), key=len)
        edges, vertex_label, group = [], [], []
        vertices = {}
        for (u, v) in giant.edges:
            if u not in vertices:
                vertices[u] = len(vertices)
                vertex_label.append(self.labels[u])
                group.append(self.label_dict[self.labels[u]])
            if v not in vertices:
                vertices[v] = len(vertices)
                vertex_label.append(self.labels[v])
                group.append(self.label_dict[self.labels[v]])
            edges.append((vertices[u], vertices[v]))

        opts = {'dim': 2, 'directed': True, 'weighted': True, 'title': 'Original Network'}
        # show_network(edges, vertex_label, group, **opts)

    def attribute_network(self):
        catgories = ['AI', 'DB', 'HCI']  # Agents AI DB IR ML HCI
        ids = [v for v in self.labels if self.labels[v] in catgories]
        graph = self.graph.subgraph(ids)
        giant = max(nx.connected_component_subgraphs(graph), key=len)
        ids = list(giant.nodes)
        vectors = [self.samples[v] for v in ids]
        spectural = SpectralEmbedding(n_neighbors=4)
        spectural.fit(np.array(vectors))
        affinity = spectural.affinity_matrix_
        graph = nx.Graph(affinity)
        graph.remove_edges_from(graph.selfloop_edges())
        # giant = max(inet.connected_component_subgraphs(graph), key=len)
        giant = graph

        # remove top degree nodes
        max_deg, max_u = 0, None
        for (u, deg) in giant.degree:
            if deg > max_deg:
                max_u = u
                max_deg = deg
        giant.remove_node(max_u)

        edges, vertex_label, group = [], [], []
        vertices = {}
        for (u, v) in giant.edges:
            if u > v:
                continue
            if u not in vertices:
                vertices[u] = len(vertices)
                vertex_label.append(self.labels[ids[u]])
                group.append(self.label_dict[self.labels[ids[u]]])
            if v not in vertices:
                vertices[v] = len(vertices)
                vertex_label.append(self.labels[ids[v]])
                group.append(self.label_dict[self.labels[ids[v]]])
            edges.append((vertices[u], vertices[v]))

        opts = {'dim': 3, 'directed': True, 'weighted': True, 'title': 'Attribute Network', 'height': 600, 'width': 600}
        # show_network(edges, vertex_label, group, **opts)

