import os
import random
import numpy as np
import torch

from netra.trainer import Trainer
from netra.utils import to_gpu, generate_walks, Dataset
from netra.configs import *


def netra(edge_path, content_path, out_folder, emsize=128, walk_per_node=30,
          walk_length=20, train_percent=0.8, epochs=2, supervise=True):
    """
    nerta embedding function

    :param edge_path: edge list file
    :param content_path: attribute and label file
    :param out_folder: output directory name
    :param emsize: size of vertex embeddings
    :param walk_per_node: number of random walks to start at each node
    :param walk_length: length of the random walk started at each node
    :param train_percent: training percentage
    :param epochs: maximum number of epochs
    :param supervise: supervised training or not
    """
    parser = set_parameters()
    args, _ = parser.parse_known_args()

    args.edge_path = edge_path
    args.content_path = content_path
    args.out_folder = out_folder
    args.emsize = emsize
    args.walk_per_node = walk_per_node
    args.walk_length = walk_length
    args.train_percent = train_percent
    args.epochs = epochs
    args.supervise = supervise

    # make output directory if it doesn't exist
    if not os.path.exists(args.out_folder):
        os.makedirs(args.out_folder)

    # Set the random seed manually for reproducibility.
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        if not args.cuda:
            logger.warning("warning: you have a CUDA device, so you should probably run with --cuda")
        else:
            torch.cuda.manual_seed(args.seed)
    else:
        args.cuda = False

    raw_data = Dataset(args)
    args.raw_data = raw_data
    raw_data.print_info()
    labels = raw_data.labels

    args.labels = raw_data.label_vec
    args.samples = raw_data.feature_mat

    graph = raw_data.graph
    lap = raw_data.laplacian.tocoo()
    indices = torch.LongTensor([lap.row, lap.col])
    values = torch.FloatTensor(lap.data)
    size = lap.shape
    args.laplacian = to_gpu(args.cuda, torch.sparse.FloatTensor(indices, values, size))
    args.samples = to_gpu(args.cuda, torch.FloatTensor(args.samples))
    # walk_path = args.out_folder + "walk.txt"
    walks = generate_walks(graph, args.walk_per_node, args.walk_length)
    # np.savetxt(walk_path, walks, delimiter=" ", fmt="%s")

    args.nodes = list(graph.nodes)
    vertices = np.array(range(len(args.nodes)))
    vertices = to_gpu(args.cuda, torch.from_numpy(vertices))
    args.vertices = vertices.unsqueeze(0)
    # args.labels = [args.label[w] for w in args.nodes]
    trainer = Trainer(args, walks)
    trainer.run()


if __name__ == "__main__":
    # demo 1:
    netra('../data/cora/cora.cites', '../data/cora/cora.content', '../tmp/')

    # demo 2:
    #netra('../data/cora/cora.cites', '../data/cora/cora.content', '../tmp/', supervise=True, train_percent=0.7)

    # demo 3:
    #netra('../data/cora/cora.cites', '../data/cora/cora.content', '../tmp/', supervise=False, emsize=128)
