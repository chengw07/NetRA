import argparse
import logging

formatter = logging.Formatter('[%(asctime).19s %(levelname)s "%(filename)s"] %(message)s')
logger = logging.getLogger('NetRA Project')
logger.setLevel("INFO")

console = logging.StreamHandler()           # define a Handler writes INFO messages or higher to the sys.stderr
console.setFormatter(formatter)             # tell the handler to use this format
logger.addHandler(console)                  # add the handler to the root logger


def set_parameters():
    """
    all parameter configurations for NetRA platform
    :return: parser
    """
    parser = argparse.ArgumentParser(description='NetRA')

    # Path Arguments
    parser.add_argument('--edge_path', type=str, default='../data/cora/cora.cites', help='edge list file')
    parser.add_argument('--content_path', type=str, default='../data/cora/cora.content', help='attribute and label file')
    parser.add_argument('--out_folder', type=str, default='../tmp/', help='output directory name')

    # Graph Processing Arguments
    parser.add_argument('--walk_per_node', default=30, type=int, help='number of random walks to start at each node')
    parser.add_argument('--undirected', default=True, type=bool, help='treat graph as undirected.')
    parser.add_argument('--walk_length', default=20, type=int, help='length of the random walk started at each node')

    # Model Arguments
    parser.add_argument('--emsize', type=int, default=128, help='size of vertex embeddings')
    parser.add_argument('--nhidden', type=int, default=128, help='number of hidden units per layer')
    parser.add_argument('--nlayers', type=int, default=1, help='number of layers')
    parser.add_argument('--noise_r', type=float, default=0.1, help='stdev of noise for autoencoder (regularizer)')
    parser.add_argument('--noise_anneal', type=float, default=0.9995,
                        help='anneal noise_r exponentially by this every 100 iterations')
    parser.add_argument('--hidden_init', action='store_true', help="initialize decoder hidden state with encoder's")
    parser.add_argument('--arch_g', type=str, default='128-128', help='generator architecture (MLP)')
    parser.add_argument('--arch_d', type=str, default='128-128', help='critic/discriminator architecture (MLP)')
    parser.add_argument('--arch_classify', type=str, default='128-128', help='classifier architecture')
    parser.add_argument('--z_size', type=int, default=32, help='dimension of random noise z to feed into generator')
    parser.add_argument('--temp', type=float, default=1, help='softmax temperature (lower --> more discrete)')
    parser.add_argument('--dropout', type=float, default=0.0, help='dropout applied to layers (0 = no dropout)')

    # Training Arguments
    parser.add_argument('--supervised', dest='supervise', action='store_true', help='supervised training')
    parser.add_argument('--unsupervised', dest='supervise', action='store_false', help='supervised training')
    parser.set_defaults(supervise=True)
    parser.add_argument('--train_percent', type=float, default=0.8, help='training percentage')
    parser.add_argument('--epochs', type=int, default=2, help='maximum number of epochs')
    parser.add_argument('--batch_size', type=int, default=512, metavar='N', help='batch size')
    parser.add_argument('--niters_ae', type=int, default=1, help='number of autoencoder iterations in training')
    parser.add_argument('--niters_sup', type=int, default=20, help='number of sup_netra iterations in training')
    parser.add_argument('--niters_gan_d', type=int, default=5, help='number of discriminator iterations in training')
    parser.add_argument('--niters_gan_g', type=int, default=1, help='number of generator iterations in training')
    parser.add_argument('--niters_gan_ae', type=int, default=1, help='number of gan-into-ae iterations in training')
    parser.add_argument('--niters_gan_schedule', type=str, default='',
                        help='epoch counts to increase number of GAN training iterations (increment by 1 each time)')
    parser.add_argument('--lr_ae', type=float, default=1, help='autoencoder learning rate')
    parser.add_argument('--lr_gan_g', type=float, default=1e-04, help='generator learning rate')
    parser.add_argument('--lr_gan_d', type=float, default=1e-04, help='critic/discriminator learning rate')
    parser.add_argument('--lr_classify', type=float, default=1e-04, help='classifier learning rate')
    parser.add_argument('--beta1', type=float, default=0.5, help='beta1 for adam. default=0.5')
    parser.add_argument('--clip', type=float, default=1, help='gradient clipping, max norm')
    parser.add_argument('--gan_gp_lambda', type=float, default=0.1, help='WGAN GP penalty lambda')
    parser.add_argument('--grad_lambda', type=float, default=0.01, help='WGAN into AE lambda')
    parser.add_argument('--lambda_class', type=float, default=1, help='lambda on classifier')

    # Evaluation Arguments
    parser.add_argument('--sample', action='store_true', help='sample when decoding for generation')
    parser.add_argument('--log_interval', type=int, default=20, help='interval to log autoencoder training results')

    # Other
    parser.add_argument('--seed', type=int, default=1111, help='random seed')
    parser.add_argument('--cuda', dest='cuda', action='store_true', help='use CUDA')
    parser.set_defaults(cuda=True)
    parser.add_argument('--device_id', type=str, default='0')

    return parser
