import torch
import torch.nn as nn
from torch.nn import init
import torch.nn.functional as F
from torch.autograd import Variable
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

from netra.utils import to_gpu

import json
import os
import numpy as np
from numpy import linalg as la
from sklearn.preprocessing import normalize
import networkx as nx


class Discriminator(nn.Module):
    """
    Class discriminator
    """
    def __init__(self, ninput, noutput, layers, activation=nn.LeakyReLU(0.2)):
        super().__init__()
        self.ninput = ninput
        self.noutput = noutput

        layer_sizes = [ninput] + [int(x) for x in layers.split('-')]
        self.layers = nn.ModuleList([])

        for i in range(len(layer_sizes)-1):
            layer = nn.Linear(layer_sizes[i], layer_sizes[i+1])
            self.layers.append(layer)
            # self.add_module("layer"+str(i+1), layer)

            # No batch normalization after first layer
            # TODO: varify performance changes if BN on all layers
            if i != 0:
                bn = nn.BatchNorm1d(layer_sizes[i+1], eps=1e-05, momentum=0.1)
                self.layers.append(bn)
                # self.add_module("bn"+str(i+1), bn)

            self.layers.append(activation)
            # self.add_module("activation"+str(i+1), activation)

        layer = nn.Linear(layer_sizes[-1], noutput)
        self.layers.append(layer)
        # self.add_module("layer"+str(len(self.layers)), layer)

        self.init_weights()

    def forward(self, x):
        for i, layer in enumerate(self.layers):
            x = layer(x)
        # TODO: why no nn.Sigmoid()
        x = torch.mean(x)
        return x

    def init_weights(self):
        init_std = 0.02
        for layer in self.layers:
            try:
                layer.weight.data.normal_(0, init_std)
                layer.bias.data.fill_(0)
            except:
                pass


class Generator(nn.Module):
    """
    Class generator
    """
    def __init__(self, ninput, noutput, layers, activation=nn.ReLU()):
        super().__init__()
        self.ninput = ninput
        self.noutput = noutput

        layer_sizes = [ninput] + [int(x) for x in layers.split('-')]
        self.layers = []

        for i in range(len(layer_sizes)-1):
            layer = nn.Linear(layer_sizes[i], layer_sizes[i+1])
            self.layers.append(layer)
            self.add_module("layer"+str(i+1), layer)

            bn = nn.BatchNorm1d(layer_sizes[i+1], eps=1e-05, momentum=0.1)
            self.layers.append(bn)
            self.add_module("bn"+str(i+1), bn)

            self.layers.append(activation)
            self.add_module("activation"+str(i+1), activation)

        layer = nn.Linear(layer_sizes[-1], noutput)
        self.layers.append(layer)
        self.add_module("layer"+str(len(self.layers)), layer)

        self.init_weights()

    def forward(self, x):
        for i, layer in enumerate(self.layers):
            x = layer(x)
        return x

    def init_weights(self):
        init_std = 0.02
        for layer in self.layers:
            try:
                layer.weight.data.normal_(0, init_std)
                layer.bias.data.fill_(0)
            except:
                pass


class Seq2Seq(nn.Module):
    """
    Class sequence to sequence autoencoder with LSTM
    """
    def __init__(self, emsize, nhidden, ntokens, nlayers, noise_r=0.2,
                 hidden_init=False, dropout=0, gpu=False, pretrain=None):
        super(Seq2Seq, self).__init__()
        self.nhidden = nhidden
        self.emsize = emsize
        self.ntokens = ntokens
        self.nlayers = nlayers
        self.noise_r = noise_r
        self.hidden_init = hidden_init
        self.dropout = dropout
        self.gpu = gpu
        self.pretrain = pretrain

        self.start_symbols = to_gpu(gpu, Variable(torch.ones(10, 1).long()))

        self.embedding = nn.Embedding.from_pretrained(torch.FloatTensor(pretrain), freeze=False)
        self.embedding_decoder = nn.Embedding(ntokens, emsize)

        # RNN Encoder and Decoder
        self.encoder = nn.LSTM(input_size=emsize,
                               hidden_size=nhidden,
                               num_layers=nlayers,
                               dropout=dropout,
                               batch_first=True)

        decoder_input_size = emsize + nhidden
        self.decoder = nn.LSTM(input_size=decoder_input_size,
                               hidden_size=nhidden,
                               num_layers=1,
                               dropout=dropout,
                               batch_first=True)

        # Initialize Linear Transformation
        self.linear = nn.Linear(nhidden, ntokens)

        self.init_weights()

        self.embedding_in = None
        self.embedding_in_hidden = None
        self.embedding_out = None
        self.embedding_out_hidden = None

    def init_weights(self):
        initrange = 0.1

        # Initialize Vocabulary Matrix Weight
        self.embedding_decoder.weight.data.uniform_(-initrange, initrange)

        # Initialize Encoder and Decoder Weights
        for p in self.encoder.parameters():
            p.data.uniform_(-initrange, initrange)
        for p in self.decoder.parameters():
            p.data.uniform_(-initrange, initrange)

        # Initialize Linear Weight
        self.linear.weight.data.uniform_(-initrange, initrange)
        self.linear.bias.data.fill_(0)

    def init_hidden(self, bsz):
        zeros1 = Variable(torch.zeros(self.nlayers, bsz, self.nhidden))
        zeros2 = Variable(torch.zeros(self.nlayers, bsz, self.nhidden))
        return to_gpu(self.gpu, zeros1), to_gpu(self.gpu, zeros2)

    def init_state(self, bsz):
        zeros = Variable(torch.zeros(self.nlayers, bsz, self.nhidden))
        return to_gpu(self.gpu, zeros)

    def store_grad_norm(self, grad):
        norm = torch.norm(grad, 2, 1)
        self.grad_norm = norm.detach().data.mean()
        return grad

    def forward(self, indices, lengths, noise, encode_only=False):
        batch_size, maxlen = indices.size()

        hidden = self.encode(indices, lengths, noise)

        if encode_only:
            return hidden

        if hidden.requires_grad:
            hidden.register_hook(self.store_grad_norm)

        decoded = self.decode(hidden, batch_size, maxlen, indices=indices, lengths=lengths)

        return decoded

    def encode(self, indices, lengths, noise):
        embeddings = self.embedding(indices)
        self.embedding_in = embeddings

        packed_embeddings = pack_padded_sequence(embeddings, lengths=lengths, batch_first=True)

        # Encode
        packed_output, state = self.encoder(packed_embeddings)
        self.embedding_in_hidden = packed_output

        hidden, cell = state
        # batch_size x nhidden
        hidden = hidden[-1]  # get hidden state of last layer of encoder

        # normalize to unit ball (l2 norm of 1) - p=2, dim=1
        norms = torch.norm(hidden, 2, 1)
        
        # For older versions of PyTorch use:
        # hidden = torch.div(hidden, norms.expand_as(hidden))
        # For newest version of PyTorch (as of 8/25) use this:
        hidden = torch.div(hidden, norms.unsqueeze(1).expand_as(hidden))

        if noise and self.noise_r > 0:
            gauss_noise = torch.normal(mean=torch.zeros(hidden.size()), std=self.noise_r)
            hidden = hidden + to_gpu(self.gpu, Variable(gauss_noise))

        return hidden

    def decode(self, hidden, batch_size, maxlen, indices=None, lengths=None):
        # batch x hidden
        all_hidden = hidden.unsqueeze(1).repeat(1, maxlen, 1)

        if self.hidden_init:
            # initialize decoder hidden state to encoder output
            state = (hidden.unsqueeze(0), self.init_state(batch_size))
        else:
            state = self.init_hidden(batch_size)

        embeddings = self.embedding_decoder(indices)
        self.embedding_out = embeddings

        augmented_embeddings = torch.cat([embeddings, all_hidden], 2)
        packed_embeddings = pack_padded_sequence(augmented_embeddings, lengths=lengths, batch_first=True)

        packed_output, state = self.decoder(packed_embeddings, state)
        output, lengths = pad_packed_sequence(packed_output, batch_first=True)
        self.embedding_out_hidden = output

        # reshape to batch_size*maxlen x nhidden before linear over vocab
        decoded = self.linear(output.contiguous().view(-1, self.nhidden))
        decoded = decoded.view(batch_size, maxlen, self.ntokens)

        return decoded

    def generate(self, hidden, maxlen, sample=False, temp=1.0):
        """Generate through decoder; no backprop"""

        batch_size = hidden.size(0)

        if self.hidden_init:
            # initialize decoder hidden state to encoder output
            state = (hidden.unsqueeze(0), self.init_state(batch_size))
        else:
            state = self.init_hidden(batch_size)

        # <sos>
        self.start_symbols.data.resize_(batch_size, 1)
        self.start_symbols.data.fill_(1)

        embedding = self.embedding_decoder(self.start_symbols)
        inputs = torch.cat([embedding, hidden.unsqueeze(1)], 2)

        # unroll
        all_indices = []
        for i in range(maxlen):
            output, state = self.decoder(inputs, state)
            overvocab = self.linear(output.squeeze(1))

            if not sample:
                vals, indices = torch.max(overvocab, 1)
            else:
                # sampling
                probs = F.softmax(overvocab/temp)
                indices = torch.multinomial(probs, 1)

            all_indices.append(indices)

            embedding = self.embedding_decoder(indices)
            inputs = torch.cat([embedding, hidden.unsqueeze(1)], 2)

        max_indices = torch.cat(all_indices, 1)

        return max_indices

    def get_embedding(self, indices, lengths):
        self.forward(indices, lengths, noise=False)
        return self.embedding_in, self.embedding_in_hidden, self.embedding_out, self.embedding_out_hidden


class PolicyNet(nn.Module):
    """
    Class policy network
    """
    def __init__(self, ninput, noutput=36):
        super(PolicyNet, self).__init__()
        nhidden = int(ninput / 2)
        assert nhidden * 2 == ninput
        self.fc1 = nn.Linear(ninput, nhidden)
        self.fc2 = nn.Linear(ninput, noutput)
        self.fc3 = nn.Linear(noutput, 1)  # Prob of Left

    def forward(self, x, y):
        x1 = F.relu(self.fc1(x))
        x2 = F.relu(self.fc1(y))
        x = torch.cat([x1, x2], dim=1)
        x = F.relu(self.fc2(x))
        x = F.sigmoid(self.fc3(x))
        return x


class Encoder(nn.Module):
    """
    Encodes a node's using 'convolutional' approach
    """
    def __init__(self, features, feature_dim, embed_dim, aggregator, num_sample,
                 base_model=None, gcn=False, cuda=False, feature_transform=False):
        super(Encoder, self).__init__()

        self.features = features
        self.feat_dim = feature_dim
        self.aggregator = aggregator
        self.num_sample = num_sample
        if base_model:
            self.base_model = base_model

        self.gcn = gcn
        self.embed_dim = embed_dim
        self.cuda = cuda
        self.aggregator.cuda = cuda
        self.weight = nn.Parameter(torch.FloatTensor(embed_dim, self.feat_dim if self.gcn else 2 * self.feat_dim))
        init.xavier_uniform(self.weight)

    def forward(self, nodes, adj_lists):
        if adj_lists[0]!=set():
            neigh_feats = self.aggregator.forward(nodes, adj_lists, self.num_sample)
        else:
            neigh_feats = None
        if not self.gcn:
            if self.cuda:
                self_feats = self.features(torch.LongTensor(nodes).cuda())
            else:
                self_feats = self.features(torch.LongTensor(nodes))
            if neigh_feats is None:
                print('features are none..')
            combined = torch.cat([self_feats, neigh_feats], dim=1)
        else:
            if adj_lists[0] != set():
                combined = neigh_feats+self.features(torch.LongTensor(nodes))
            else:
                combined = self.features(torch.LongTensor(nodes))
        combined = F.relu(self.weight.mm(combined.t()))
        return combined


class Aggregator(nn.Module):
    """
    Aggregates a node's embeddings using mean of neighbors' embeddings
    """
    def __init__(self, features, cuda=False, gcn=False):
        super(Aggregator, self).__init__()
        self.features = features
        self.cuda = cuda
        self.gcn = gcn

    def forward(self, nodes, to_neighs, num_sample):
        _set = set
        samp_neighs = to_neighs
        if self.gcn:
            samp_neighs = [samp_neigh + set([nodes[i]]) for i, samp_neigh in enumerate(samp_neighs)]

        unique_nodes_list = list(set.union(*samp_neighs))
        unique_nodes = {n:i for i,n in enumerate(unique_nodes_list)}
        mask = Variable(torch.zeros(len(samp_neighs), len(unique_nodes)))
        column_indices = [unique_nodes[n] for samp_neigh in samp_neighs for n in samp_neigh]
        row_indices = [i for i in range(len(samp_neighs)) for j in range(len(samp_neighs[i]))]
        mask[row_indices, column_indices] = 1
        if self.cuda:
            mask = mask.cuda()
        num_neigh = mask.sum(1, keepdim=True)
        mask = mask.div(num_neigh)
        if self.cuda:
            embed_matrix = self.features(torch.LongTensor(unique_nodes_list).cuda())
        else:
            if num_sample == 5:
                embed_matrix = self.features(torch.LongTensor(unique_nodes_list))
            else:
                embed_matrix = self.features(torch.LongTensor(unique_nodes_list))
        to_feats = mask.mm(embed_matrix)
        return to_feats


class SupervisedNetRA(nn.Module):
    """
    Class supervised version of NetRA platform
    """
    def __init__(self, num_classes, enc):
        super(SupervisedNetRA, self).__init__()
        self.enc = enc
        self.xent = nn.CrossEntropyLoss()

        self.weight = nn.Parameter(torch.FloatTensor(num_classes, enc.embed_dim))
        init.xavier_uniform(self.weight)

    def forward(self, nodes,adj):
        embeds = self.enc(nodes,adj)
        scores = self.weight.mm(embeds)
        return scores.t()

    def forward_emb(self, nodes, adj):
        embeds = self.enc(nodes, adj)
        # scores = self.weight.mm(embeds)
        return embeds.t()

    def loss(self, nodes, labels, adj):
        scores = self.forward(nodes, adj)
        return self.xent(scores, labels.squeeze())


class PreTraining(object):
    """
    Class pretraining
    """

    def __init__(self, args):
        self.args = args
        self.graph = self.args.raw_data.graph
        self.dim = self.args.emsize

        adj = nx.adjacency_matrix(self.graph, nodelist=range(len(args.labels)))
        self.adj = np.matrix(adj/np.sum(adj, axis=1))
        self.num_nodes = self.adj.shape[0]
        self.id_mat = np.matrix(np.identity(self.num_nodes))
        self.replicate_mat = np.zeros((self.num_nodes, self.dim))
        self.vectors = {}

        self.forward()

    def get_svd(self, id_mat, alpha=0.5):
        prob = np.log(1.0 / self.num_nodes)
        prob_trans_mat = np.log(id_mat / np.tile(np.sum(id_mat, axis=0), (self.num_nodes, 1))) - prob
        prob_trans_mat[prob_trans_mat < 0] = 0
        prob_trans_mat[prob_trans_mat == np.nan] = 0
        u_mat, s_mat, _ = la.svd(prob_trans_mat)
        u_res = u_mat[:, 0:self.dim]
        s_res = s_mat[0:self.dim]
        return np.array(u_res)*np.power(s_res, alpha).reshape(self.dim)

    def forward(self):
        self.id_mat = np.dot(self.id_mat, self.adj)
        result = self.get_svd(self.id_mat)
        result = normalize(result, axis=1, norm='l2')
        self.replicate_mat = result

        # get embeddings
        look_back = list(self.args.raw_data.dictionary.items())
        for i, embedding in enumerate(self.replicate_mat):
            self.vectors[look_back[i][0]] = embedding


def load_models(load_path, epoch):
    """
    load saved models
    :param load_path: model path
    :param epoch: epoch number
    :return: model parameters
    """
    model_args = json.load(open("{}/args.json".format(load_path), "r"))
    word2idx = json.load(open("{}/vocab.json".format(load_path), "r"))
    idx2word = {v: k for k, v in word2idx.items()}

    autoencoder = Seq2Seq(emsize=model_args['emsize'],
                              nhidden=model_args['nhidden'],
                              ntokens=model_args['ntokens'],
                              nlayers=model_args['nlayers'],
                              hidden_init=model_args['hidden_init'])

    gan_gen = Generator(ninput=model_args['z_size'],
                    noutput=model_args['nhidden'],
                    layers=model_args['arch_g'])
    gan_disc = Discriminator(ninput=model_args['nhidden'],
                     noutput=1,
                     layers=model_args['arch_d'])

    print('Loading models from'+load_path)
    ae_path = os.path.join(load_path, "autoencoder_model_{}.pt".format(epoch))
    gen_path = os.path.join(load_path, "gan_gen_model_{}.pt".format(epoch))
    disc_path = os.path.join(load_path, "gan_disc_model_{}.pt".format(epoch))

    autoencoder.load_state_dict(torch.load(ae_path))
    gan_gen.load_state_dict(torch.load(gen_path))
    gan_disc.load_state_dict(torch.load(disc_path))
    return model_args, idx2word, autoencoder, gan_gen, gan_disc


def generate(autoencoder, gan_gen, z, vocab, sample, maxlen):
    """
    Assume noise is batch_size x z_size
    """
    if type(z) == Variable:
        noise = z
    elif type(z) == torch.FloatTensor or type(z) == torch.cuda.FloatTensor:
        noise = Variable(z, volatile=True)
    elif type(z) == np.ndarray:
        noise = Variable(torch.from_numpy(z).float(), volatile=True)
    else:
        raise ValueError("Unsupported input type (noise): {}".format(type(z)))

    gan_gen.eval()
    autoencoder.eval()

    # generate from random noise
    fake_hidden = gan_gen(noise)
    max_indices = autoencoder.generate(hidden=fake_hidden,
                                       maxlen=maxlen,
                                       sample=sample)

    max_indices = max_indices.data.cpu().numpy()
    sentences = []
    for idx in max_indices:
        # generated sentence
        words = [vocab[x] for x in idx]
        # truncate sentences to first occurrence of <eos>
        truncated_sent = []
        for w in words:
            if w != '<eos>':
                truncated_sent.append(w)
            else:
                break
        sent = " ".join(truncated_sent)
        sentences.append(sent)

    return sentences
