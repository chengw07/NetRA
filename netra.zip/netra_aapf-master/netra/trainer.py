import sys
import random
from torch.distributions import Bernoulli
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable

from netra.utils import to_gpu, batchify, export_embeddings
from netra.models import Seq2Seq, Discriminator, Generator, PolicyNet, Encoder, Aggregator, SupervisedNetRA, PreTraining
from netra.classification import *

from tqdm import tqdm


class Trainer:
    """
    Training class of NetRA platform
    """
    def __init__(self, args, walks):
        """
        training initialization
        :param args: parameters
        :param corpus: input data
        """
        self.train = walks
        self.args = args
        self.ntokens = len(self.args.labels)
        self.one = to_gpu(self.args.cuda, torch.tensor(1.0))
        self.minus_one = self.one * -1

        self.__get_pretrain()
        self.autoencoder = Seq2Seq(emsize=args.emsize, nhidden=args.nhidden, ntokens=self.ntokens,
                                   nlayers=args.nlayers, noise_r=args.noise_r, hidden_init=args.hidden_init,
                                   dropout=args.dropout, gpu=args.cuda, pretrain=self.args.pretrain)

        self.generator = Generator(ninput=args.z_size, noutput=args.nhidden, layers=args.arch_g)
        self.discriminator = Discriminator(ninput=args.nhidden, noutput=1, layers=args.arch_d)
        self.policynet = PolicyNet(ninput=args.emsize)
        feat_data = self.args.raw_data.feature_mat
        features = nn.Embedding(self.ntokens, self.args.raw_data.attribute_dim)
        features.weight = nn.Parameter(torch.FloatTensor(feat_data), requires_grad=False)
        agg = Aggregator(features, cuda=True)
        enc = Encoder(features, self.args.raw_data.attribute_dim, args.emsize, agg, num_sample=10, gcn=True, cuda=False)
        self.sup_netra = SupervisedNetRA(self.args.raw_data.num_class, enc)

        # logger.info(self.autoencoder)
        # logger.info(self.generator)
        # logger.info(self.discriminator)

        self.optim_autoencoder = optim.SGD(self.autoencoder.parameters(), lr=args.lr_ae)
        self.optim_generator = optim.Adam(self.generator.parameters(), lr=args.lr_gan_g, betas=(args.beta1, 0.999))
        self.optim_discriminator = optim.Adam(self.discriminator.parameters(), lr=args.lr_gan_d, betas=(args.beta1, 0.999))
        self.optim_policy = torch.optim.Adam(self.policynet.parameters(), lr=0.0001)
        self.optim_sup_netra = torch.optim.SGD(filter(lambda p: p.requires_grad, self.sup_netra.parameters()), lr=0.7)

        self.criterion = nn.CrossEntropyLoss()

        if args.cuda:
            self.autoencoder = self.autoencoder.cuda()
            self.generator = self.generator.cuda()
            self.discriminator = self.discriminator.cuda()
            self.criterion = self.criterion.cuda()

    def __get_pretrain(self):
        model = PreTraining(self.args)
        vectors = model.vectors
        pretrain = []
        for word, idx in self.args.raw_data.dictionary.items():
            vec = vectors[word]
            pretrain.append(vec)
        self.args.pretrain = pretrain

    def train_autoencoder(self, batch):
        """
        autoencoder training with batch data
        :param batch: a batch data
        :return: autonecoder loss, accuracy and embedding loss
        """
        self.autoencoder.train()
        self.optim_autoencoder.zero_grad()

        source, target, lengths = batch
        source = to_gpu(self.args.cuda, Variable(source))
        target = to_gpu(self.args.cuda, Variable(target))

        # walk mask over padding
        mask = target.gt(0)
        masked_target = target.masked_select(mask)
        output_mask = mask.unsqueeze(1).expand(mask.size(0), self.ntokens)
        output = self.autoencoder(source, lengths, noise=True)

        # dot = make_dot(self.autoencoder(source, lengths, noise=True), params=dict(self.autoencoder.named_parameters()))
        # dot.render(self.args.out_path + 'autoencoder-viz', format='pdf', view=False)

        flat_output = output.view(-1, self.ntokens)
        masked_output = flat_output.masked_select(output_mask).view(-1, self.ntokens)
        loss = self.criterion(masked_output / self.args.temp, masked_target) * self.args.grad_lambda

        embeddings = self.__fatch_embeddings()
        embedding_transpose = torch.transpose(embeddings, 0, 1)

        # pytorch doesn’t support dense * sparse matrix multiplication right now.
        # At least one of sparse_tensor.mm(dense_tensor), torch.mm(sparse_tensor, dense_tensor) should work.
        embedding_loss = torch.mm(self.args.laplacian, embeddings)
        embedding_loss = torch.trace(torch.mm(embedding_transpose, embedding_loss)) / self.ntokens * self.args.grad_lambda

        loss += embedding_loss
        loss.backward()

        # `clip_grad_norm` to prevent exploding gradient in RNNs / LSTMs
        torch.nn.utils.clip_grad_norm_(self.autoencoder.parameters(), self.args.clip)
        self.optim_autoencoder.step()

        probs = F.softmax(masked_output, dim=-1)
        max_vals, max_indices = torch.max(probs, 1)
        accuracy = torch.mean(max_indices.eq(masked_target).float()).item()

        loss_autoencoder = loss.item()

        return loss_autoencoder, accuracy, embedding_loss

    def train_generator(self):
        """
        generator training
        :return: generator loss
        """
        self.generator.train()
        self.generator.zero_grad()

        noise = to_gpu(self.args.cuda, Variable(torch.ones(self.args.batch_size, self.args.z_size)))
        noise.data.normal_(0, 1)
        fake_hidden = self.generator(noise)

        # dot = make_dot(self.generator(noise), params=dict(self.generator.named_parameters()))
        # dot.render('netviz', view=True)
        err_generator = self.discriminator(fake_hidden)
        err_generator.backward(self.one)
        self.optim_generator.step()

        return - err_generator

    def __calc_gradient_penalty(self, discriminator, real_data, fake_data):
        """
        from https://github.com/caogang/wgan-gp/blob/master/gan_cifar10.py
        :param discriminator: discriminator class
        :param real_data: real data
        :param fake_data: fake data
        :return: gradient penalty
        """
        bsz = real_data.size(0)
        alpha = torch.rand(bsz, 1)
        alpha = alpha.expand(bsz, real_data.size(1))  # only works for 2D XXX
        # alpha = alpha.cuda()
        alpha = to_gpu(self.args.cuda, alpha)
        interpolates = alpha * real_data + ((1 - alpha) * fake_data)
        interpolates = Variable(interpolates, requires_grad=True)
        disc_interpolates = discriminator(interpolates)

        grad_outputs = to_gpu(self.args.cuda, torch.ones(disc_interpolates.size()))

        gradients = torch.autograd.grad(outputs=disc_interpolates, inputs=interpolates,
                                        grad_outputs=grad_outputs,
                                        create_graph=True, retain_graph=True, only_inputs=True)[0]

        gradients = gradients.view(gradients.size(0), -1)

        gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean() * self.args.gan_gp_lambda
        return gradient_penalty

    def train_discriminator(self, batch):
        """
        discriminator training with batch data
        :param batch: a batch of data
        :return:errors from discriminator
        """
        # clamp parameters to a cube
        for p in self.discriminator.parameters():
            p.data.clamp_(-self.args.grad_lambda, self.args.grad_lambda)

        self.discriminator.train()
        self.optim_discriminator.zero_grad()

        # positive samples ----------------------------
        # generate real codes
        source, target, lengths = batch
        source = to_gpu(self.args.cuda, Variable(source))
        target = to_gpu(self.args.cuda, Variable(target))

        # batch_size x nhidden
        real_hidden = self.autoencoder(source, lengths, noise=False, encode_only=True)

        # loss / backprop
        err_discriminator_real = self.discriminator(real_hidden)
        err_discriminator_real.backward(self.one)

        # negative samples ----------------------------
        # generate fake codes
        noise = to_gpu(self.args.cuda, Variable(torch.ones(self.args.batch_size, self.args.z_size)))
        noise.data.normal_(0, 1)

        # loss / backprop
        fake_hidden = self.generator(noise)
        err_discriminator_fake = self.discriminator(fake_hidden.detach())
        err_discriminator_fake.backward(self.minus_one)

        # gradient penalty
        # gradient_penalty = -1 * self.__calc_gradient_penalty(self.discriminator, real_hidden.data, fake_hidden.data)
        # gradient_penalty.backward()
        torch.nn.utils.clip_grad_norm_(self.autoencoder.parameters(), self.args.clip)

        self.optim_discriminator.step()
        # D_cost = D_fake - D_real + gradient_penalty
        # Wasserstein_D = D_real - D_fake
        err_discriminator = err_discriminator_real - err_discriminator_fake

        return err_discriminator, err_discriminator_real, err_discriminator_fake

    def train_discriminator_autoencoder(self, batch):
        """
        training discriminator and autoencoder adversarially
        :param batch: a batch of data
        :return: discriminator error
        """
        self.autoencoder.train()
        self.optim_autoencoder.zero_grad()

        source, target, lengths = batch
        source = to_gpu(self.args.cuda, Variable(source))
        real_hidden = self.autoencoder(source, lengths, noise=False, encode_only=True)
        # real_hidden.register_hook(self.__grad_hook)
        err_discriminator_real = self.discriminator(real_hidden)
        err_discriminator_real.backward(self.minus_one)
        # torch.nn.utils.clip_grad_norm_(self.autoencoder.parameters(), self.args.clip)

        self.optim_autoencoder.step()

        return err_discriminator_real

    def __grad_hook(self, grad):
        return grad * self.args.grad_lambda

    def train_sup_netra(self, train):
        """training supervised NetRA"""
        batch_nodes = train[:256]
        random.shuffle(train)

        adj_dqn1 = self.__get_batch_adj(batch_nodes)

        self.optim_sup_netra.zero_grad()
        loss = self.sup_netra.loss(batch_nodes,
                                   Variable(torch.LongTensor(self.args.raw_data.label_vec[np.array(batch_nodes)])),
                                   adj_dqn1)
        loss.backward()
        self.optim_sup_netra.step()

    def __get_batch_adj(self, batch_nodes):
        """
        get adjacency edgelist for a batch
        :param batch_nodes: a batch of data
        :return: adjacency edgelist
        """
        adj_dqn = []
        for node in batch_nodes:
            temp_adj = []
            adj_lists_new_null = [set(temp_adj)]
            state = self.sup_netra.forward_emb([node], adj_lists_new_null)
            for adj in self.args.raw_data.adj_list[node]:
                probs = self.policynet(state, self.sup_netra.forward_emb([adj], adj_lists_new_null))
                m = Bernoulli(probs)
                action = m.sample()
                action = action.data.numpy().astype(int)[0]
                if action != 0:
                    temp_adj.append(adj)
                state = self.sup_netra.forward_emb([node], [set(temp_adj)])
            if len(temp_adj) == 0:
                temp_adj.extend(random.sample(self.args.raw_data.adj_list[node], 1))
            adj_dqn.append(set(temp_adj))
        return adj_dqn

    def train_policy(self, train):
        """
        training policy network for graph denoising
        :param train: training data
        """
        gamma = 0.99

        state_pool = []
        state2_pool = []
        action_pool = []
        reward_pool = []
        done_pool = []
        steps = 0

        e = 0
        batch_nodes = train[:256]
        random.shuffle(train)
        all_total_reward = []
        for node in batch_nodes:
            e = e + 1
            t = 0
            temp_adj = []
            adj_lists_new_null = [set(temp_adj)]
            state = self.sup_netra.forward_emb([node], adj_lists_new_null)
            total_reward = 0
            done = False
            for item in self.args.raw_data.adj_list[node]:
                state2 = self.sup_netra.forward_emb([item], adj_lists_new_null).detach()
                probs = self.policynet(state, state2)
                m = Bernoulli(probs)
                action = m.sample()
                action = action.data.numpy().astype(int)[0]

                if action[0] != 0:
                    temp_adj.append(item)
                adj_lists_new = [set(temp_adj)]

                val_output = self.sup_netra.forward([node], adj_lists_new)
                reward = f1_score(self.args.raw_data.label_vec[[node]], val_output.data.numpy().argmax(axis=1),
                                  average="micro")
                if reward == 0:
                    reward = -5
                if t == len(self.args.raw_data.adj_list[node]):
                    done = True
                else:
                    done = False
                # if done:
                #     reward = 0
                total_reward += reward

                state_pool.append(state)
                state2_pool.append(state2)
                action_pool.append(float(action))
                reward_pool.append(reward)
                done_pool.append(done)

                state = self.sup_netra.forward_emb([node], adj_lists_new)

                steps += 1
                t = t + 1

                if done:
                    all_total_reward.append(total_reward)

            # Update policy
            if e > 0 and e % 2 == 0:

                # Discount reward
                running_add = 0
                for i in reversed(range(steps)):
                    if done_pool[i]:
                        running_add = reward_pool[i]
                    else:
                        running_add = running_add * gamma + reward_pool[i]
                        # reward_pool[i] = running_add

                # Normalize reward
                reward_mean = np.mean(reward_pool)
                reward_std = np.std(reward_pool)
                for i in range(steps):
                    reward_pool[i] = (reward_pool[i] - reward_mean) / (reward_std + 1e-7)

                # Gradient Desent
                self.optim_policy.zero_grad()
                # print('steps',steps)
                for i in range(steps):
                    state = state_pool[i]
                    state_2 = state2_pool[i]
                    action = Variable(torch.FloatTensor([action_pool[i]]))
                    reward = reward_pool[i]

                    probs = self.policynet(state, state_2)
                    m = Bernoulli(probs)
                    loss = -m.log_prob(action) * reward  # Negtive score function x reward
                    loss.backward()

                self.optim_policy.step()

                state_pool = []
                action_pool = []
                reward_pool = []
                steps = 0

    def run(self):
        """
        run training module
        """
        if self.args.supervise:
            logger.info("supervised training...")
            train_percent = self.args.train_percent
            train_num = int(self.ntokens * train_percent)
            rand_indices = np.random.permutation(self.ntokens)
            train = list(rand_indices[:train_num])
            val = rand_indices[train_num:]

            for epoch in tqdm(range(1, self.args.epochs + 1)):
                for it in range(self.args.niters_sup):
                    self.train_sup_netra(train)
                for k in range(self.args.niters_sup):
                    self.train_policy(train)
            adj_dqn = self.__get_batch_adj(val)
            val_output = self.sup_netra.forward(val, adj_dqn)
            f1 = f1_score(self.args.raw_data.label_vec[val], val_output.data.numpy().argmax(axis=1), average="micro")
            logger.info("classification with %.2f%% percent labeled data..." % (train_percent * 100))
            logger.info("epoch: %d/%d, validation set F1: %.4f" % (epoch, self.args.epochs, f1))

            adj_dqn = self.__get_batch_adj(list(range(self.ntokens)))
            embed = self.sup_netra.forward_emb(list(range(self.ntokens)), adj_dqn)
            # embed = self.sup_netra.forward_emb(list(range(self.ntokens)), self.args.raw_data.adj_list)

            export_embeddings(embed.data.numpy(), list(range(self.ntokens)), args=self.args)
    
        else:
            train_data = batchify(self.train, self.args.batch_size, shuffle=True)
            logger.info("unsupervised training...")
    
            # schedule of increasing GAN training loops
            if self.args.niters_gan_schedule != "":
                gan_schedule = [int(x) for x in self.args.niters_gan_schedule.split("-")]
            else:
                gan_schedule = []
            niter_gan = 1
    
            fixed_noise = to_gpu(self.args.cuda, Variable(torch.ones(self.args.batch_size, self.args.z_size)))
            fixed_noise.data.normal_(0, 1)
    
            loss_ae = []
            for epoch in tqdm(range(1, self.args.epochs + 1)):
                # update gan training schedule
                if epoch in gan_schedule:
                    niter_gan += 1
                    logger.info("GAN training loop schedule increased to {}".format(niter_gan))
    
                total_loss_autoencoder = 0
                niter_global = 1
    
                # loop through all batches in training data
                for niter in tqdm(range(len(train_data))):
                    # train autoencoder
                    loss_autoencoder, accuracy, embedding_loss = 0, 0, 0
                    for i in range(self.args.niters_ae):
                        if niter == len(train_data):
                            break  # end of epoch
                        loss_autoencoder, accuracy, embedding_loss = self.train_autoencoder(train_data[niter])
                        total_loss_autoencoder += loss_autoencoder
                        niter += 1
    
                    # train gan
                    err_disc, err_disc_real, err_disc_fake, err_gen = 0, 0, 0, 0
                    for k in range(niter_gan):
    
                        # train discriminator/critic
                        for i in range(self.args.niters_gan_d):
                            # feed a seen sample within this epoch; good for early training
                            batch = train_data[random.randint(0, len(train_data)-1)]
                            err_disc, err_disc_real, err_disc_fake = self.train_discriminator(batch)
    
                        # train generator
                        for i in range(self.args.niters_gan_g):
                            err_gen = self.train_generator()
    
                        # train autoencoder from d
                        for i in range(self.args.niters_gan_ae):
                            batch = train_data[random.randint(0, len(train_data) - 1)]
                            err_disc_real = self.train_discriminator_autoencoder(batch)
    
                    niter_global += 1
                    if niter_global % self.args.log_interval == 0:
                        # exponentially decaying noise on autoencoder
                        self.autoencoder.noise_r = self.autoencoder.noise_r * self.args.noise_anneal
    
                # loss_ae.append(err_gen.item())
                # if epoch > 1:
                #     show_loss([epoch - 1, epoch], loss_ae[-2:], env=self.args.dataset)
    
                # shuffle between epochs
                train_data = batchify(self.train, self.args.batch_size, shuffle=True)
    
            # check embedding results
            embeddings = self.__fatch_embeddings(show=False)
            export_embeddings(embeddings.detach().cpu().numpy(), list(range(self.ntokens)), args=self.args)
    
            # embeddings = torch.cat((embeddings, self.args.samples), 1)
            score_classification(embeddings, np.array(self.args.labels), p_labeled=self.args.train_percent)
            # score_classification(self.args.raw_data.feature_mat, self.args.raw_data.label_vec)

    def __fatch_embeddings(self, show=False):
        """
        get embedding data for evaluation
        :param show: visualization of the embeddings
        :return: embedding
        """
        results = self.autoencoder.get_embedding(self.args.vertices, [self.ntokens])
        embeddings = results[0].squeeze()
        # if show:
        #     show_embedding(embeddings, self.args.label, env=self.args.dataset)

        return embeddings
